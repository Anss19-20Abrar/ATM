class Snode{
    int val;
    Snode next;

public Snode(int val) {
       super();
       this.val = val;
   }
   }
